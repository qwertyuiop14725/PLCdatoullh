import { ok, fail, toInt } from '../_utils.js';

/**
 * GET /api/list  用户列表
 * query: keyword（可选，按 name/email 模糊搜索）、limit、offset
 */
export async function onRequestGet(context) {
  const { request, env } = context;
  try {
    const url = new URL(request.url);
    const keyword = (url.searchParams.get('keyword') || '').trim();
    const limit = toInt(url.searchParams.get('limit'), 100, 1, 200);
    const offset = toInt(url.searchParams.get('offset'), 0, 0, 100000);

    const where = [];
    const binds = [];
    if (keyword) {
      where.push('(name LIKE ? OR email LIKE ?)');
      binds.push(`%${keyword}%`, `%${keyword}%`);
    }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

    const list = await env.cunchu
      .prepare(`SELECT id, name, email, created_at FROM users ${whereSql} ORDER BY id DESC LIMIT ? OFFSET ?`)
      .bind(...binds, limit, offset)
      .all();

    const total = await env.cunchu
      .prepare(`SELECT COUNT(*) AS total FROM users ${whereSql}`)
      .bind(...binds)
      .first();

    return ok({
      items: list.results || [],
      total: total ? total.total : 0,
      limit,
      offset,
    });
  } catch (error) {
    return fail(error, 500);
  }
}
