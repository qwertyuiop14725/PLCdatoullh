import { ok, fail, toInt } from '../../_utils.js';
import { listMessages } from './_store.js';

/**
 * GET /api/messages/list
 * query: after（增量 id）、limit、offset、order=asc|desc、keyword
 */
export async function onRequestGet(context) {
  const { request, env } = context;
  try {
    const url = new URL(request.url);
    const after = toInt(url.searchParams.get('after'), 0, 0, 1e12);
    const limit = toInt(url.searchParams.get('limit'), 50, 1, 200);
    const offset = toInt(url.searchParams.get('offset'), 0, 0, 1e6);
    const keyword = (url.searchParams.get('keyword') || '').trim();
    const order = url.searchParams.get('order') === 'desc' && after === 0 ? 'DESC' : 'ASC';

    const { items, total } = await listMessages(env.cunchu, { after, limit, offset, order, keyword });
    return ok({ items, total, limit, offset });
  } catch (error) {
    return fail(error, 500);
  }
}
