-- ============================================================
-- Cloudflare D1 初始化脚本
-- 用法（本地）：npx wrangler d1 execute cunchu --file=./schema.sql
-- 用法（线上）：npx wrangler d1 execute cunchu --remote --file=./schema.sql
-- ============================================================

-- 用户表（项目已存在，IF NOT EXISTS 保证幂等）
CREATE TABLE IF NOT EXISTS users (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  email      TEXT NOT NULL UNIQUE,
  created_at TEXT DEFAULT (datetime('now'))
);

-- 聊天消息表（新增）
CREATE TABLE IF NOT EXISTS messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_name  TEXT NOT NULL,
  content    TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

-- 聊天室按 id 增量拉取，索引让轮询更快
CREATE INDEX IF NOT EXISTS idx_messages_id         ON messages(id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);
