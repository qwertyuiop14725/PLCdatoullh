import { ok, fail, readJson, checkAdmin, unauthorized } from '../_utils.js';

/**
 * DELETE /api/delete  删除用户
 * body 或 query 传 id，例如 /api/delete?id=1 或 { "id": 1 }
 */
export async function onRequestDelete(context) {
  const { request, env } = context;
  try {
    if (!checkAdmin(request, env).ok) return unauthorized();

    const url = new URL(request.url);
    const queryId = url.searchParams.get('id');
    const body = await readJson(request).catch(() => null);
    const id = parseInt(queryId !== null ? queryId : body && body.id, 10);

    if (Number.isNaN(id)) return fail('缺少有效的 id');

    const result = await env.cunchu
      .prepare('DELETE FROM users WHERE id = ?')
      .bind(id)
      .run();

    if (result.success && result.meta && result.meta.changes > 0) {
      return ok({ id, deleted: result.meta.changes });
    }
    return fail('用户不存在或已被删除', 404);
  } catch (error) {
    return fail(error, 500);
  }
}
