import { ok, fail, readJson, checkAdmin, unauthorized } from '../../_utils.js';
import { deleteMessage } from './_store.js';

/**
 * DELETE /api/messages/delete?id=1   或 body { "id": 1 }
 * 后台管理专用，需要管理口令
 */
export async function onRequestDelete(context) {
  const { request, env } = context;
  try {
    if (!checkAdmin(request, env).ok) return unauthorized();

    const url = new URL(request.url);
    const queryId = url.searchParams.get('id');
    const body = queryId === null ? await readJson(request).catch(() => null) : null;
    const id = parseInt(queryId !== null ? queryId : body && body.id, 10);
    if (Number.isNaN(id)) return fail('缺少有效的 id');

    const result = await deleteMessage(env.cunchu, id);
    if (result.success && result.meta && result.meta.changes > 0) {
      return ok({ id, deleted: result.meta.changes });
    }
    return fail('消息不存在或已被删除', 404);
  } catch (error) {
    return fail(error, 500);
  }
}
