/**
 * 消息数据访问层（_ 开头不会被注册成路由）
 */

export const MAX_CONTENT = 500;

export function buildWhere({ after = 0, keyword = '' } = {}) {
  const where = [];
  const binds = [];
  if (keyword) {
    where.push('(content LIKE ? OR user_name LIKE ?)');
    binds.push(`%${keyword}%`, `%${keyword}%`);
  }
  if (after > 0) {
    where.push('id > ?');
    binds.push(after);
  }
  return { whereSql: where.length ? `WHERE ${where.join(' AND ')}` : '', binds };
}

export async function listMessages(db, { after = 0, limit = 50, offset = 0, order = 'ASC', keyword = '' } = {}) {
  const { whereSql, binds } = buildWhere({ after, keyword });
  const list = await db
    .prepare(`SELECT id, user_name, content, created_at FROM messages ${whereSql} ORDER BY id ${order} LIMIT ? OFFSET ?`)
    .bind(...binds, limit, offset)
    .all();
  const totalRow = await db
    .prepare(`SELECT COUNT(*) AS total FROM messages ${whereSql}`)
    .bind(...binds)
    .first();
  return { items: list.results || [], total: totalRow ? totalRow.total : 0 };
}

export async function insertMessage(db, user_name, content) {
  return db
    .prepare('INSERT INTO messages (user_name, content) VALUES (?, ?) RETURNING id, user_name, content, created_at')
    .bind(user_name, content)
    .first();
}

export async function deleteMessage(db, id) {
  return db.prepare('DELETE FROM messages WHERE id = ?').bind(id).run();
}
