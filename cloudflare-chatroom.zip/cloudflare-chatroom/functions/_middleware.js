import { corsHeaders } from './_utils.js';

/**
 * 全局中间件：处理 CORS 预检，并为所有响应补上跨域头
 */
export async function onRequest(context) {
  const { request, next } = context;

  if (request.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  const response = await next();
  const wrapped = new Response(response.body, response);
  Object.entries(corsHeaders).forEach(([key, value]) => wrapped.headers.set(key, value));
  return wrapped;
}
