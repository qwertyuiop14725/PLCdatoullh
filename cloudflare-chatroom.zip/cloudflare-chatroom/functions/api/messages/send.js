import { ok, fail, readJson } from '../../_utils.js';
import { insertMessage, MAX_CONTENT } from './_store.js';

/**
 * POST /api/messages/send
 * body: { user_name, content }
 */
export async function onRequestPost(context) {
  const { request, env } = context;
  try {
    const body = await readJson(request) || {};
    const user_name = String(body.user_name || '').trim();
    const content = String(body.content || '').trim();

    if (!user_name) return fail('请先设置昵称');
    if (user_name.length > 32) return fail('昵称不能超过 32 个字符');
    if (!content) return fail('消息内容不能为空');
    if (content.length > MAX_CONTENT) return fail(`消息不能超过 ${MAX_CONTENT} 个字符`);

    const row = await insertMessage(env.cunchu, user_name, content);
    return ok(row, 201);
  } catch (error) {
    return fail(error, 500);
  }
}
