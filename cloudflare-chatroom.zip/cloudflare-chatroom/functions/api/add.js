import { ok, fail, readJson, checkAdmin, unauthorized } from '../_utils.js';

/**
 * POST /api/add  新增用户
 * body: { name, email }
 */
export async function onRequestPost(context) {
  const { request, env } = context;
  try {
    if (!checkAdmin(request, env).ok) return unauthorized();

    const body = await readJson(request);
    const name = (body && body.name ? String(body.name) : '').trim();
    const email = (body && body.email ? String(body.email) : '').trim().toLowerCase();

    if (!name) return fail('昵称不能为空');
    if (name.length > 32) return fail('昵称不能超过 32 个字符');
    if (!email) return fail('邮箱不能为空');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail('邮箱格式不正确');

    const exist = await env.cunchu
      .prepare('SELECT id FROM users WHERE email = ?')
      .bind(email)
      .first();
    if (exist) return fail('该邮箱已存在');

    const result = await env.cunchu
      .prepare('INSERT INTO users (name, email) VALUES (?, ?) RETURNING id, name, email, created_at')
      .bind(name, email)
      .first();

    return ok(result, 201);
  } catch (error) {
    return fail(error, 500);
  }
}
