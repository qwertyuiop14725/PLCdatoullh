/**
 * Pages Functions 公共工具
 * 注意：文件名以 _ 开头，不会被注册成路由
 */

export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Token',
  'Access-Control-Max-Age': '86400',
};

/** 统一 JSON 响应：{ success, data? , error? } */
export function json(payload, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      ...corsHeaders,
      ...extraHeaders,
    },
  });
}

export function ok(data, status = 200) {
  return json({ success: true, data }, status);
}

export function fail(error, status = 400) {
  return json({ success: false, error: String(error && error.message ? error.message : error) }, status);
}

/** 解析请求体，失败返回 null */
export async function readJson(request) {
  try {
    const text = await request.text();
    if (!text) return null;
    return JSON.parse(text);
  } catch {
    return null;
  }
}

export function toInt(value, fallback, min, max) {
  const n = parseInt(value, 10);
  if (Number.isNaN(n)) return fallback;
  if (min !== undefined && n < min) return min;
  if (max !== undefined && n > max) return max;
  return n;
}

/**
 * 轻量后台鉴权：
 * - 未配置 ADMIN_TOKEN 时直接放行（本地开发默认可用）
 * - 配置了则要求请求头 X-Admin-Token 一致
 */
export function checkAdmin(request, env) {
  const expected = env && env.ADMIN_TOKEN;
  if (!expected) return { ok: true };
  const provided = request.headers.get('X-Admin-Token') || '';
  return { ok: provided === expected };
}

export function unauthorized() {
  return fail('未授权：请在后台填写正确的管理口令（X-Admin-Token）', 401);
}
