# Cloudflare 聊天室 · 带后台管理

原生 HTML + Tailwind CDN + Pages Functions + D1，零构建、直接部署。

## 目录结构

```
.
├── index.html                      # 聊天室（访客端）
├── admin.html                      # 后台管理面板
├── schema.sql                      # D1 建表脚本
├── wrangler.toml                   # D1 绑定（binding = cunchu）
├── .dev.vars.example               # 后台口令示例
└── functions/
    ├── _utils.js                   # JSON 响应 / 鉴权等公共方法（不注册为路由）
    ├── _middleware.js              # CORS 预检与跨域头
    └── api/
        ├── list.js                 # GET    /api/list              用户列表
        ├── add.js                  # POST   /api/add               新增用户
        ├── delete.js               # DELETE /api/delete?id=1       删除用户
        └── messages/
            ├── _store.js           # 消息数据访问层（不注册为路由）
            ├── list.js             # GET    /api/messages/list     消息列表
            ├── send.js             # POST   /api/messages/send     发送消息
            └── delete.js           # DELETE /api/messages/delete   删除消息
```

## 一、初始化数据库

```bash
npm i                                   # 安装 wrangler
npx wrangler login                      # 首次使用需登录

npm run db:init                         # 本地 D1 建表
npm run db:init:remote                  # 线上 D1 建表（必须执行一次）
```

`users` 表已存在时 `CREATE TABLE IF NOT EXISTS` 会跳过，只会新增 `messages` 表与索引。

## 二、本地开发

```bash
cp .dev.vars.example .dev.vars          # 可选：设置后台口令
npm run dev                             # wrangler pages dev .
```

打开 http://localhost:8788 进入聊天室，/admin.html 进入后台。

## 三、部署到 Cloudflare Pages

1. 控制台 → Workers & Pages → Create → Pages → 直接上传，或用 Git 连接仓库。
2. 构建配置：**构建命令留空**，输出目录填 `/`（根目录）。
3. Settings → Functions → D1 database bindings：变量名 `cunchu` → 数据库 `cunchu`（已在控制台确认绑定）。
4. Settings → Environment variables：添加 `ADMIN_TOKEN`（可选，作为后台口令）。
5. 部署后执行一次 `npm run db:init:remote` 建表。

也可命令行部署：`npm run deploy`（`wrangler pages deploy .`）。

## 四、接口说明

所有接口返回统一格式：`{ "success": true, "data": ... }` 或 `{ "success": false, "error": "..." }`，均带 try-catch。

| 方法 | 路径 | 说明 | 鉴权 |
| --- | --- | --- | --- |
| GET | `/api/list` | 用户列表，支持 `keyword` / `limit` / `offset` | 否 |
| POST | `/api/add` | 新增用户 `{ name, email }` | 口令 |
| DELETE | `/api/delete?id=1` | 删除用户 | 口令 |
| GET | `/api/messages/list` | 消息列表，支持 `after`（增量）/ `limit` / `offset` / `order` / `keyword` | 否 |
| POST | `/api/messages/send` | 发送消息 `{ user_name, content }`（≤500 字） | 否 |
| DELETE | `/api/messages/delete?id=1` | 删除消息 | 口令 |

## 五、实现要点

- **实时性**：Pages 不支持 WebSocket/Durable Objects，聊天室采用 3 秒轮询 + `?after=lastId` 增量拉取，只取新消息；页面重新可见时立即补拉一次。
- **轻量鉴权**：未配置 `ADMIN_TOKEN` 时后台写操作直接放行；配置后，后台页面把口令存在 localStorage 并通过 `X-Admin-Token` 请求头发送。
- **安全**：消息渲染全部使用 `textContent`，杜绝 XSS；SQL 一律使用 `prepare().bind()` 参数化。
- **时间显示**：D1 的 `datetime('now')` 是 UTC，前端统一按 UTC 解析后转本地时区显示。

## 六、常见问题

- **接口报 `no such table: messages`**：线上库还没执行 `npm run db:init:remote`。
- **后台删除提示未授权**：检查环境变量 `ADMIN_TOKEN` 与后台填写的口令是否一致，改完需要重新部署。
- **本地能跑线上不行**：确认 Pages 的 D1 绑定变量名就是 `cunchu`，与 `wrangler.toml` 保持一致。
